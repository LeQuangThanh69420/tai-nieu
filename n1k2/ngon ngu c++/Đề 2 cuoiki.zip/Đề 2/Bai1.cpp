#include <iostream>

using namespace std;

int main() {
	int d, m, y, h, mn, s;
	cin >> h >> mn >> s >> m >> d >> y;
	cout << "[" << h << ":" << mn << ":" << s << " " << m << "/" << d << "/" << y << "]";
	return 0;
}
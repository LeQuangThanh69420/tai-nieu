#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main() {
	int n;
	int a[2000];
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> a[i];
	}
	int sum = 0;
	for (int i = 0; i < n; i++) {
		sum += a[i];
	}
	int average = sum / n;
	int max = a[0];
	for (int i = 1; i < n; i++) {
		if (max < a[i]) {
			max = a[i];
		}
	}
	cout << abs(average - max);
}
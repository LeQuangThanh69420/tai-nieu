#include <iostream>
#include <math.h>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

class TaiKhoan {
	string soTaiKhoan;
	string tenNganHang;
	int soDu;
	int hanMuc;
	double laiSuatNam;
public:
	TaiKhoan();
	TaiKhoan(string soTK, string tenNH, int mucUuTien, double lsNam);
	string getSoTaiKhoan() const;
	string getTenNganHang() const;
	int getSoDu() const;
	void napTien(int soTien);
	void rutTien(int soTien);
	double getLaiNgay() const;
};

TaiKhoan::TaiKhoan()
{
}

TaiKhoan::TaiKhoan(string soTK, string tenNH, int mucUuTien, double lsNam)
	:soTaiKhoan(soTK), tenNganHang(tenNH), soDu(0), hanMuc(mucUuTien), laiSuatNam(lsNam)
{
}

string TaiKhoan::getSoTaiKhoan() const
{
	return soTaiKhoan;
}

string TaiKhoan::getTenNganHang() const
{
	return tenNganHang;
}

int TaiKhoan::getSoDu() const
{
	return soDu;
}

void TaiKhoan::napTien(int soTien)
{
	soDu += soTien;
}

void TaiKhoan::rutTien(int soTien)
{
	if (soDu >= soTien) {
		soDu -= soTien;
	}
}

double TaiKhoan::getLaiNgay() const
{
	return (soDu * laiSuatNam / 365) / 100;
}

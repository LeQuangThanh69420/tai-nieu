#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main() {
	double x, y;
	cin >> x >> y;
	double t = 0;
	if (x > 30 && y>30) {
		t = sqrt(x+y);
	}
	else if (x <= 30 && x >= 0 && y >=0 && y<= 30) {
		t = (exp(x)) / (exp(y) + exp(x));
	}
	cout << fixed << setprecision(6) << t;
}
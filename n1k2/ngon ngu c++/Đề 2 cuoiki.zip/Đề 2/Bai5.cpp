#include <iostream>
#include <math.h>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

int main() {
	int n;
	double a[100][7];
	ifstream scan;
	scan.open("chaybo.txt");
	if (scan.good() == true) {
		scan >> n;
		scan.ignore();
		for (int i = 0; i < n; i++) {
			string s;
			getline(scan, s, '\t');
			for (int j = 0; j < 7; j++) {
				scan >> a[i][j];
			}
		}
		scan.close();
	}
	else
	{
		return 0;
	}
	double b[100] = {0};
	
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < 7; j++) {
			b[i] += a[i][j];
		}
	}
	double max = b[0];
	for (int i = 0; i < n; i++) {
		if (max < b[i]) {
			max = b[i];
		}
	}
	cout << fixed << setprecision(1) << max;
	return 0;
}
#include <iostream>
#include <math.h>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

class TaiKhoan {
	string soTaiKhoan;
	string tenNganHang;
	int soDu;
	int hanMuc;
	double laiSuatNam;
public:
	TaiKhoan();
	TaiKhoan(string soTK, string tenNH, int mucUuTien, double lsNam);
	string getSoTaiKhoan() const;
	string getTenNganHang() const;
	int getSoDu() const;
	void napTien(int soTien);
	void rutTien(int soTien);
	double getLaiNgay() const;
};

TaiKhoan::TaiKhoan()
{
}

TaiKhoan::TaiKhoan(string soTK, string tenNH, int mucUuTien, double lsNam)
	:soTaiKhoan(soTK), tenNganHang(tenNH), soDu(0), hanMuc(mucUuTien), laiSuatNam(lsNam)
{
}

string TaiKhoan::getSoTaiKhoan() const
{
	return soTaiKhoan;
}

string TaiKhoan::getTenNganHang() const
{
	return tenNganHang;
}

int TaiKhoan::getSoDu() const
{
	return soDu;
}

void TaiKhoan::napTien(int soTien)
{
	soDu += soTien;
}

void TaiKhoan::rutTien(int soTien)
{
	if (soDu >= soTien) {
		soDu -= soTien;
	}
}

double TaiKhoan::getLaiNgay() const
{
	return (soDu * laiSuatNam / 365) / 100;
}

void printTaiKhoan(const string& filename, TaiKhoan* tk, int n) {
	ofstream write;
	write.open(filename);
	if (write.good() == true) {
		write << left << setw(6) << "STT"
			<< setw(20) << "So tai khoan"
			<< setw(20) << "Ngan hang"
			<< setw(20) << "So du"
			<< setw(16) << "Lai ngay" << endl;
		for (int i = 0; i < n; i++) {
			write << left << setw(6) << i + 1
				<< setw(20) << tk[i].getSoTaiKhoan()
				<< setw(20) << tk[i].getTenNganHang()
				<< setw(20) << tk[i].getSoDu()
				<< fixed << setprecision(0) << setw(16) << tk[i].getLaiNgay() << endl;
		}
		write.close();
	}
}

TaiKhoan* inputTaiKhoan(int& soLuongTK);

void swap(TaiKhoan& xp, TaiKhoan& yp)
{
	TaiKhoan temp = xp;
	xp = yp;
	yp = temp;
}

void Sort(TaiKhoan* dstk, int n)
{
	int i, j, max_idx;
	for (i = 0; i < n - 1; i++)
	{
		max_idx = i;
		for (j = i + 1; j < n; j++)
			if (dstk[j].getLaiNgay() > dstk[max_idx].getLaiNgay())
				max_idx = j;

		swap(dstk[max_idx], dstk[i]);
	}
}
int main() {
	int n;
	TaiKhoan* dstk = inputTaiKhoan(n);
	for (int i = 0; i < n; i++) {
		int nNap, nRut;
		cin >> nNap >> nRut;
		dstk[i].napTien(nNap);
		dstk[i].rutTien(nRut);
	}
	Sort(dstk, n);
	printTaiKhoan("taikhoan_output.txt", dstk, n);
	delete dstk;
	return 0;
}
#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main() {
	double x;
	cin >> x;
	double t = 0;
	if (x > 6.0) {
		t = ((sin(x) + cos(2 * x)) /( (x + 3.5) * (x - 5.3)));
	}
	else if (x <= 2) {
		t = (sin(2 * x) - cos(x)) * tan(2 * x / (x * x + 1));
	}
	cout << fixed << setprecision(8) << t;
}
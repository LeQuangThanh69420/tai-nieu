#include <iostream>

using namespace std;

int main() {
	int d, m, y, h, mn, s;
	cin >> d >> m >> y >> h >> mn >> s;
	cout << "[" << d << "-" << m << "-" << y << " " << h << ":" << mn << ":" << s << "]";
	return 0;
}
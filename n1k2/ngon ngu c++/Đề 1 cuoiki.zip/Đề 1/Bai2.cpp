#include <iostream>

using namespace std;

int main() {
	int m, s, h;
	cin >> h >> m >> s;
	if (h <= 11) {
		cout << "[" << h << ":" << m << ":" << s << " AM]";
	}
	else if(h==12) {
		cout << "[" << h << ":" << m << ":" << s << " PM]";
	}
	else {
		cout << "[" << h - 12 << ":" << m << ":" << s << " PM]";
	}
}
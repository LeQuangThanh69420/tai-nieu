#include <iostream>
#include <math.h>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

int main() {
	int n;
	int a[100][7];
	ifstream scan;
	scan.open("trongcay.txt");
	if (scan.good() == true) {
		scan >> n;
		scan.ignore();
		for (int i = 0; i < n; i++) {
			string s;
			getline(scan, s, '\t');
			for (int j = 0; j < 7; j++) {
				scan >> a[i][j];
			}
		}
		scan.close();
	}
	else
	{
		return 0;
	}
	int b[7] = {0};
	for (int j = 0; j < 7; j++) {
		for (int i = 0; i < n; i++) {
			b[j] += a[i][j];
		}
	}
	int max = b[0];
	for (int i = 0; i < 7; i++) {
		if (max < b[i]) {
			max = b[i];
		}
	}
	cout << max;
	return 0;
}

#include <iostream>
#include <math.h>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

class MatHang {
private:
	string tenMatHang;
	int soHangCon;
	int donGia;
	int mucGiamGia;
	int soDaBan;
public:
	MatHang();
	MatHang(string ten, int dg, int mgg);
	string getTen() const;
	int getSoHangCon() const;
	int getSoDaBan() const;
	int getDoanhThu() const;
	void nhapHang(int soLuongNhapThem);
	void xuatHang(int soLuongHangXuat);
	void setTen(string s);
	void setSoHangCon(int t);
	void setDonGia(int t);
	void setMucGiamGia(int t);
	void setSoDaBan(int t);
};

MatHang::MatHang() {}

MatHang::MatHang(string ten, int dg, int mgg) :tenMatHang(ten), donGia(dg), mucGiamGia(mgg), soHangCon(0), soDaBan(0) {}

string MatHang::getTen() const {
	return tenMatHang;
}

int MatHang::getSoHangCon() const {
	return soHangCon;
}

int MatHang::getSoDaBan() const {
	return soDaBan;
}

void MatHang::nhapHang(int soLuongNhapThem) {
	soHangCon += soLuongNhapThem;
}

void MatHang::xuatHang(int soLuongHangXuat) {
	if (soHangCon >= soLuongHangXuat) {
		soHangCon -= soLuongHangXuat;
		soDaBan += soLuongHangXuat;
	}
}

void MatHang::setTen(string s)
{
	tenMatHang = s;
}

void MatHang::setSoHangCon(int t)
{
	soHangCon = t;
}

void MatHang::setDonGia(int t)
{
	donGia = t;
}

void MatHang::setMucGiamGia(int t)
{
	mucGiamGia = t;
}

void MatHang::setSoDaBan(int t)
{
	soDaBan = t;
}

int MatHang::getDoanhThu() const {
	return soDaBan * donGia * (100 - mucGiamGia) / 100;
}

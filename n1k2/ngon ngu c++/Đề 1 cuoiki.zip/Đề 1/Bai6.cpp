#include <iostream>
#include <math.h>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

struct HocSinh {
	string sHoTen;
	int aSoCay[7];
};

bool check(HocSinh hs) {
	int result = 1;
	int f[7];
	for (int i = 0; i <7 ; i++) {
		f[i] = 0;
		for (int j = 0; j < i; j++) if (hs.aSoCay[j] < hs.aSoCay[i]) {
			f[i] = max(f[i], f[j] + 1);
		}
		result = max(result, f[i]);
	}
	return result >= 3;
}

int main() {
	int n;
	HocSinh dshs[100];
	ifstream scan;
	scan.open("trongcay.txt");
	if (scan.good() == true) {
		scan >> n;
		for (int i = 0; i < n; i++) {
			scan.ignore();
			getline(scan, dshs[i].sHoTen, '\t');
			for (int j = 0; j < 7; j++) {
				scan >> dshs[i].aSoCay[j];
			}
		}
		scan.close();
	}
	else
	{
		return 0;
	}
	for (int i = 0; i < n; i++) {
		if (check(dshs[i])) {
			cout << dshs[i].sHoTen << endl;
		}
	}
	return 0;
}
#include <iostream>
#include <math.h>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

class MatHang {
private:
	string tenMatHang;
	int soHangCon;
	int donGia;
	int mucGiamGia;
	int soDaBan;
public:
	MatHang();
	MatHang(string ten, int dg, int mgg);
	string getTen() const;
	int getSoHangCon() const;
	int getSoDaBan() const;
	int getDoanhThu() const;
	void nhapHang(int soLuongNhapThem);
	void xuatHang(int soLuongHangXuat);
	void setTen(string s);
	void setSoHangCon(int t);
	void setDonGia(int t);
	void setMucGiamGia(int t);
	void setSoDaBan(int t);
};

MatHang::MatHang() {}

MatHang::MatHang(string ten, int dg, int mgg) :tenMatHang(ten), donGia(dg), mucGiamGia(mgg), soHangCon(0), soDaBan(0) {}

string MatHang::getTen() const {
	return tenMatHang;
}

int MatHang::getSoHangCon() const {
	return soHangCon;
}

int MatHang::getSoDaBan() const {
	return soDaBan;
}

void MatHang::nhapHang(int soLuongNhapThem) {
	soHangCon += soLuongNhapThem;
}

void MatHang::xuatHang(int soLuongHangXuat) {
	if (soHangCon >= soLuongHangXuat) {
		soHangCon -= soLuongHangXuat;
		soDaBan += soLuongHangXuat;
	}
}

void MatHang::setTen(string s)
{
	tenMatHang = s;
}

void MatHang::setSoHangCon(int t)
{
	soHangCon = t;
}

void MatHang::setDonGia(int t)
{
	donGia = t;
}

void MatHang::setMucGiamGia(int t)
{
	mucGiamGia = t;
}

void MatHang::setSoDaBan(int t)
{
	soDaBan = t;
}

int MatHang::getDoanhThu() const {
	return soDaBan * donGia * (100 - mucGiamGia) / 100;
}

void writeMatHang(const string& filename, MatHang* mh, int n) {
	ofstream write;
	write.open(filename);
	if (write.good() == true) {
		write << left << setw(6) << "STT"
			<< setw(24) << "Ten mat hang"
			<< setw(16) << "So hang con"
			<< setw(16) << "So da ban"
			<< setw(16) << "Doanh thu" << endl;
		for (int i = 0; i < n; i++) {
			write << left << setw(6) << i + 1
				<< setw(24) << mh[i].getTen()
				<< setw(16) << mh[i].getSoHangCon()
				<< setw(16) << mh[i].getSoDaBan()
				<< fixed << setprecision(0) << setw(16) << mh[i].getDoanhThu() << endl;
		}
		write.close();
	}
}

MatHang* inputMatHang(int& soLuongMatHang);
void swap(MatHang& xp, MatHang& yp)
{
	MatHang temp = xp;
	xp = yp;
	yp = temp;
}

void Sort(MatHang* dsmh , int n)
{
	int i, j, max_idx;
	for (i = 0; i < n - 1; i++)
	{
		max_idx = i;
		for (j = i + 1; j < n; j++)
			if (dsmh[j].getDoanhThu() > dsmh[max_idx].getDoanhThu())
				max_idx = j;

		swap(dsmh[max_idx], dsmh[i]);
	}
}
int main() {
	int n;
	MatHang* dsmh = inputMatHang(n);
	for (int i = 0; i < n; i++) {
		int slNhap, slXuat;
		cin >> slNhap >> slXuat;
		dsmh[i].nhapHang(slNhap);
		dsmh[i].xuatHang(slXuat);
	}
	Sort(dsmh, n);
	writeMatHang("mathang_output.txt", dsmh, n);
	delete[] dsmh;
	return 0;
}

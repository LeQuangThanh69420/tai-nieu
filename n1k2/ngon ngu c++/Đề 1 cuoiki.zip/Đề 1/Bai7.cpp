#include <iostream>
#include <math.h>
#include <iomanip>
#include <fstream>
#include <string>

using namespace std;

class MatHang {
private:
	string tenMatHang;
	int soHangCon;
	int donGia;
	int mucGiamGia;
	int soDaBan;
public:
	MatHang();
	MatHang(string ten,int dg,int mgg);
	string getTen() const;
	int getSoHangCon() const;
	int getSoDaBan() const;
};

MatHang::MatHang(){}

MatHang::MatHang(string ten, int dg, int mgg):tenMatHang(ten),donGia(dg), mucGiamGia(mgg),soHangCon(0), soDaBan(0) {}

string MatHang::getTen() const {
	return tenMatHang;
}

int MatHang::getSoHangCon() const {
	return soHangCon;
}

int MatHang::getSoDaBan() const {
	return soDaBan;
}